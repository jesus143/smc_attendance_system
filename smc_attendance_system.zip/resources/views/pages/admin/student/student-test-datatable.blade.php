<table border="0" cellpadding="0" cellspacing="0" id="example">
    <thead>
      <tr>
        <th>Column 1</th>
        <th>Column 2</th>
        <th>etc</th>
      </tr>
    </thead>
    <tbody>
    <select id="msds-select" >
    <option>None</option>
    <option>Group 1</option>
    <option>Group 2</option>
    <option>Group 3</option>
    <option>Group 4</option>
    <option>Group 5</option>
    <option>Group 6</option>
    </select>
    <tr class="odd">
        <td>Group 1</td>
        <td><img src="images/modules/download-icon.gif" width="12" height="17" alt="" /></td>
        <td><a href="#">Download</a></td>
    </tr>
    <tr class="even">
        <td>Group 1</td>
        <td><img src="images/modules/download-icon.gif" width="12" height="17" alt="" /></td>
        <td><a href="#">Download</a></td>
    </tr>
    <tr class="odd">
        <td>Group 1</td>
        <td><img src="images/modules/download-icon.gif" width="12" height="17" alt="" /></td>
        <td><a href="#">Download</a></td>
    </tr>
     <tr class="odd">
        <td>Group 2</td>
        <td><img src="images/modules/download-icon.gif" width="12" height="17" alt="" /></td>
        <td><a href="#">Download</a></td>
    </tr>
     <tr class="odd">
        <td>Group 2</td>
        <td><img src="images/modules/download-icon.gif" width="12" height="17" alt="" /></td>
        <td><a href="#">Download</a></td>
    </tr>
 </tbody>
 </table>