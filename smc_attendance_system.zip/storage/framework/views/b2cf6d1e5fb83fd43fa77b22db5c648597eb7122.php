
<h3> Event List </h3>

  <div id="signupbox" style=" margin-top:50px; width:100%"  >
    <div class="panel panel-default">
        <div class="panel-heading">
            <div class="panel-title">Personnel View</div> 
        </div>  
        <div class="panel-body" > 
        
        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>


           <table id="example" class="display" cellspacing="0" width="100%">
                <thead>
                    <tr> 
                        <th>name</th>
                        <th>venue</th>
                        <th>description</th> 
                        <th>date_time_start</th>
                        <th>date_time_end</th>
                        <th>Details</th>
                        
                        <th>Delete</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>name</th>
                        <th>venue</th>
                        <th>description</th> 
                        <th>date_time_start</th>
                        <th>date_time_end</th>
                        <th>Details</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </tfoot>
                <tbody> 
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr> 
                            <td><?php echo e($event->name); ?></td>
                            <td><?php echo e($event->venue); ?></td>
                            <td><?php echo e($event->description); ?></td> 
                            <td><?php echo e($event->date_time_start); ?></td>
                            <td><?php echo e($event->date_time_end); ?></td>  
                            <td> <a href="<?php echo e(route('attendance.show', $event->id)); ?>">Details</a> </td>
                            
                            <td>   
                            <a href="<?php echo e(route('event.show', $event->id)); ?>"> 
                                <input type="submit" value="Edit" />  
                            </a>
                            </td> 
                            <td>  
                            <form action="<?php echo e(route('event.destroy', $event->id)); ?>" method="POST" accept-charset="utf-8">
                                    <input name="_method" type="hidden" value="DELETE">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="submit" value="delete" /> 
                                </form> 
                            </td> 

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>  
                </tbody>
            </table>
        </div>
    </div>
</div>