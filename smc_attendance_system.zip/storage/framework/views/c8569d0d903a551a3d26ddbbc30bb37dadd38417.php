
<h3> Event List </h3>

  <div id="signupbox" style=" margin-top:50px; width:100%"  >
    <div class="panel panel-default">
        <div class="panel-heading">
            <div class="panel-title">Personnel View</div> 
        </div>  
        <div class="panel-body" > 

        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        
           <table id="example" class="display" cellspacing="0" width="100%">
                <thead>
                    <tr> 
                         <th>Name</th>
                        <th>Mobile Number</th> 
                        <th>Position</th> 
                        <th>Department</th>  
                        <th>Delete</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Name</th>
                        <th>Mobile Number</th> 
                        <th>Position</th> 
                        <th>Department</th>  
                        <th>Delete</th>
                    </tr>
                </tfoot>
                <tbody> 
                    <?php $__currentLoopData = $personnels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personnel): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>   
                        <td><?php echo e($personnel->first_name . ' ' . $personnel->last_name); ?></td>
                        <td><?php echo e($personnel->mobile_number); ?></td>                               
                        <td><?php echo e($personnel->position); ?></td>                               
                        <td><?php echo e($personnel->department); ?></td>                               

                        <td> 
                            <form action="<?php echo e(route('personnel.destroy', $personnel->id)); ?>" method="POST" accept-charset="utf-8">
                                <input name="_method" type="hidden" value="DELETE">
                                <?php echo e(csrf_field()); ?>

                                <input type="submit" value="delete" /> 
                            </form> 
                        </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?> 
                </tbody>
            </table>
        </div>
    </div>
</div>