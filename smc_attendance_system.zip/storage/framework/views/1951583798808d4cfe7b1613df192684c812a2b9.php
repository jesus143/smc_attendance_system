 

<div class="row bootstrap snippets"> 
    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="col-md-4 col-sm-6 content-card">
            <div class="card-big-shadow">
                <div class="card card-just-text" data-background="color" data-color="blue" data-radius="none">
                    <div class="content">
                        <h6 class="category"><?php echo e(date("F jS, Y", strtotime($event->date_time_start))); ?> - <?php echo e(date("F jS, Y", strtotime($event->date_time_end))); ?></h6> 
                        <h4 class="title"><a href="#"><?php echo e($event->name); ?></a></h4> 
                        <p> 
                            <?php echo e($event->description); ?>

                        </p> 
                        <p class="description"><a href="<?php echo e(route('attendance.show', $event->id)); ?>">more..</a>
                    </div> 
                </div> <!-- end card -->
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
 
</div>
<br>
<br>
<br>
<br>