 <div class="panel panel-default"> 
    <div class="list-group"> 
      <a href="<?php echo e(route("pages.dashboard")); ?>" class="list-group-item">Dashboard</a>
      <a href="<?php echo e(route("pages.sms")); ?>" class="list-group-item">SMS</a>
      <a href="<?php echo e(route("pages.attendance")); ?>" class="list-group-item">Attendance</a> 
    </div>
</div>