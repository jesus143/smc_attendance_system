

<select id="msds-select" class="form-control" >
	<option>None</option>  
	<?php $__currentLoopData = $data['religion']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>  
		<option value="<?php echo e($religion); ?>"><?php echo e($religion); ?></option>   
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>   
	<?php $__currentLoopData = $data['attendanceStatus']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aStat): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>  
		<option value="<?php echo e($aStat); ?>"><?php echo e($aStat); ?></option>   
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>  
</select>
<br><br> 
<br><br>

        