


<h1> Attendance Details </h1>  
<table class="table table-bordered">
    <thead>
      <tr>
        <th>Title</th>
        <th>Description</th> 
      </tr>
    </thead>
    <tbody> 

    <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
      <tr>
        <td style="width: 20%;"> name </td>
        <td><?php echo e($value->name); ?></td>
        </tr>
        <td> venue </td>
        <td><?php echo e($value->venue); ?></td>
        </tr>
        <td> description </td>
        <td><?php echo e($value->description); ?></td>
        </tr>
        <td> sponsor personnels </td>
        <td><?php echo e(App\Personnel::getNamesByIdList($value->sponsor_personnels)); ?></td>
        </tr>
        <td style="display:none"> sponsor students </td>
        <td style="display:none" ><?php echo e(App\Student::getNamesByIdList($value->sponsor_students)); ?></td>
        </tr>
        <td style="display:none"> sponsor college </td>
        <td style="display:none"><?php echo e($value->sponsor_collge); ?></td>
        </tr>
        <td style="display:none"> sponsor year </td>
        <td style="display:none"><?php echo e($value->sponsor_year); ?></td>
        </tr>
        <td> participant college </td>
        <td><?php echo e($value->participant_collge); ?></td>
        </tr>
        <td style="display:none"> participant religion </td>
        <td style="display:none"><?php echo e($value->participant_religion); ?></td>
        </tr>
        <td> participant year </td>
        <td><?php echo e($value->participant_year); ?></td>
        </tr>
        <td> date time start </td>
        <td><?php echo e($value->date_time_start); ?></td>
        </tr>
        <td> date time end </td>
        <td><?php echo e($value->date_time_end); ?></td>
        </tr> 
      </tr> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

  
    </tbody>
  </table> 
  <hr> 

