 <div class="panel panel-default"> 
    <div class="list-group"> 
      
      <a href="<?php echo e(route("pages.sms")); ?>" class="list-group-item">SMS</a>
      <a href="<?php echo e(route("pages.attendance")); ?>" class="list-group-item">ATTENDANCE</a> 
      <a href="<?php echo e(route("event.index")); ?>" class="list-group-item">EVENTS</a> 
      <a href="<?php echo e(route("personnel.index")); ?>" class="list-group-item">PERSONNEL</a> 
      <a href="<?php echo e(route("student.index")); ?>" class="list-group-item">STUDENT</a> 
    </div>
</div>