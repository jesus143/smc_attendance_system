 

<h1> Student Registered This Event Sign In</h1>  
<div id="signupbox" style=" margin-top:50px; width:100%"  >
    <div class="panel panel-default">
        <div class="panel-heading">
            <div class="panel-title">Personnel View</div> 
        </div>  
        <div class="panel-body" > 
           <table id="example" class="display" cellspacing="0" width="100%">
                <thead>
                    <tr> 
                        <th>Name</th>
                        <th>Description</th>  
                        <th>Delete</th> 
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Name</th>
                        <th>Religion</th>
                        <th>In Time</th>  
                        <th>Delete</th>
                    </tr>
                </tfoot>
                <tbody> 
                   <?php echo $__env->make("pages/admin/includes/religion-sorting", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
                    <?php $__currentLoopData = $studentEventsIn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendant): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>  
                        <tr>
                            <td> <?php echo e($attendant->first_name . ' ' . $attendant->last_name); ?></td>  
                            <td> <?php echo e($attendant->religion); ?></td>  
                            <td><?php echo e($attendant->created_at); ?></td>  
                            <td> <a href="<?php echo e(route('student.destroy', $attendant->id)); ?>">Delete</a> </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>