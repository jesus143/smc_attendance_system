
<h3>Student List</h3> 
  <div id="signupbox" style=" margin-top:50px; width:100%"  >
    <div class="panel panel-default">
        <div class="panel-heading">
            <div class="panel-title">Personnel View</div> 
        </div>  
        <div class="panel-body" > 
           <table id="example" class="display" cellspacing="0" width="100%">
                <thead>
                    <tr> 
                        <th>Religion</th> 
                        <th>Id Number</th>
                        <th>Name</th>
                        <th>Mobile Number</th> 
                        <th>Year level</th> 
                        <th>Course</th> 
                        <th>Gender</th>    
                        <th>Religion Description</th>   
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Religion</th> 
                        <th>Id Number</th>
                        <th>Name</th>
                        <th>Mobile Number</th> 
                        <th>Year level</th> 
                        <th>Course</th> 
                        <th>Gender</th>   
                        <th>Religion Description</th>   
                    </tr>
                </tfoot>
                <tbody>   
                 <select id="msds-select" class="form-control" >
                    <option>None</option>  
                    <?php $__currentLoopData = $data['religion']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>  
                        <option value="<?php echo e($religion); ?>"><?php echo e($religion); ?></option>   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>    
                </select>
                <br><br> 
                <br><br>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>  
                      <tr>
                        <td> <?php echo e($student->religion); ?> </td>
                        <td> <?php echo e($student->id_number); ?> </td>
                        <td> <?php echo e($student->first_name . ' ' . $student->last_name); ?> </td>
                        <td> <?php echo e($student->mobile_number); ?> </td>
                        <td> <?php echo e($student->year_level); ?> </td>
                        <td> <?php echo e($student->course); ?> </td>
                        <td> <?php echo e($student->gender); ?> </td>  
                        <td> <?php echo e($student->bio); ?> </td>  
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?> 
                </tbody>
            </table>
        </div>
    </div>
</div>