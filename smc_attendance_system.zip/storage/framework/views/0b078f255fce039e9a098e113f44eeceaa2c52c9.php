<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Attendance System</title>

    <!-- Styles -->
    <link href="<?php echo e(url('/public/css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('/public/css/custom_style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('/public/css/attendance.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('/public/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">   
    <link href="<?php echo e(url('/public/css/user-profile.css')); ?>" rel="stylesheet">   
     
    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>

 
 
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container header-menu-container">
                <div class="navbar-header"> 
                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        Attendance System
                     </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                            <li><a href="<?php echo e(url('/login')); ?>">Login</a></li> 
                        <?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(url('/logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <?php echo $__env->yieldContent('content'); ?>
    </div> 
 
    <script src="<?php echo e(url('/public/js/app.js')); ?>"></script>  
    <script language="JavaScript" type="text/javascript" src="<?php echo e(url('/public/js/jquery.dataTables.min.js')); ?>"></script>   
  <script>
// $(document).ready(function() { 
//     $('#example').DataTable( {
//         "paging":   5,
//         "ordering": false,
//         "info":     false
//     } );
// } );  
// do sorting 
$(document).ready(function() { 

    // make data table works as table
      $("#example").dataTable({
         "paging":   5,
        "sPaginationType": "full_numbers",
        "bFilter": true,
        // "sDom":"lrtip" 
       });  
      
      // sorting
      var oTable;
      oTable = $('#example').dataTable(); 
      $('#msds-select').change( function() {  
            var sortAs = $(this).val(); 

            console.log(sortAs); 
            if(sortAs == 'None') {  
            }  else {  
                oTable.fnFilter( sortAs );    
            }
       });
   });

  </script>
    
    
</body>
</html>
