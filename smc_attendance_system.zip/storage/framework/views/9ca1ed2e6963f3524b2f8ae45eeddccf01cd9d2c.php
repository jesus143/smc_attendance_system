<h1> Add Student for this event </h1> 

<div> 
<ul class="list-group" >
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>  
      <li  class="list-group-item alert alert-danger" > 
      <?php echo e($message); ?>

     </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

<?php if(session('message')): ?> 
  <div class="alert alert-success">
    <?php echo e(session('message')); ?>

  </div>
<?php endif; ?>
 
</ul>
</div>

<form class="form-inline" action="<?php echo e(route('student.event.store')); ?>" method="POST" >
  <?php echo e(csrf_field()); ?>

  <input type="hidden" value="<?php echo e($id); ?>" name="event_id" />
  <div class="form-group">  
    <label >Student Id Number:</label><br>
    <input type="text" class="form-control" id="student_id" name="student_id" /> 
  </div> 
  <br><br>
<div class="form-group"> 
  <label class="radio-inline"><input type="radio" name="status"  value="in" checked>In</label>
	<label class="radio-inline"><input type="radio" name="status" value="out">Out</label> 
	</div>
	<br><br> 
  <button type="submit" class="btn btn-info">Register Student</button>
</form>
<hr>