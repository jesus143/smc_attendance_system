<form>


  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Type event name">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
      <label for="exampleInputEmail1">Description</label>
      <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Type event description">
      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
    </div>
    <div class="form-group">
      <label for="exampleSelect2">Example multiple select</label>
      <select multiple class="form-control" id="exampleSelect2">
          <option value="CBA">CBA</option> 
          <option value="CAS">CAS</option> 
          <option value="COC">COC</option> 
          <option value="CON">CON</option> 
          <option value="CECS">CECS</option>  
      </select>
    </div> 

    <div class="form-group">
      <label for="exampleSelect2">Date Time Started</label>
      <input type="datetime-local"  class="form-control" >
    </div> 

    <div class="form-group">
      <label for="exampleSelect2">Date Time End</label> 
        <input type="datetime-local"  class="form-control" >
    </div> 






  <button type="submit" class="btn btn-primary">Submit</button>
</form>