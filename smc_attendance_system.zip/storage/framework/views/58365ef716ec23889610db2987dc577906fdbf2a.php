
<h3> Add Event </h3>
<br>



<?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>

  
<form method="post" action="<?php echo e(route('event.update', $id)); ?>" >  

 <input name="_method" type="hidden" value="PATCH">

  <?php echo e(csrf_field()); ?>


  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Type event name" name="name" value="<?php echo e($eventDetails->name); ?>" />
    
  </div>
  <div class="form-group">
      <label for="exampleInputEmail1">Venue</label>
      <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Type event description" name="venue" value="<?php echo e($eventDetails->venue); ?>" />
      
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Description</label>
      <textarea name="description" placeholder="Type event description" class="form-control" style="resize:none" ><?php echo e($eventDetails->description); ?></textarea>
      
    </div> 

  <div class="form-group">
      <label for="exampleInputEmail1">Sponsor</label>  
        <em><lable>Personnels</lable></em><br>
        <select name="sponsor_personnels[]" multiple class="form-control" > 
         

          <?php $__currentLoopData = $personnels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personnel): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            
            <?php if(in_array($personnel->id, App\Personnel::listIdToArray($eventDetails->sponsor_personnels))): ?>

            <option value="<?php echo e($personnel->id); ?>" selected><?php echo e($personnel->first_name  . ', ' . $personnel->department . ', ' . $personnel->last_name); ?>,  
            <?php echo e($personnel->position); ?></option>   
            <?php else: ?> 
              <option value="<?php echo e($personnel->id); ?>"><?php echo e($personnel->first_name  . ', ' . $personnel->department . ', ' . $personnel->last_name); ?>,  
            <?php echo e($personnel->position); ?></option>  

            <?php endif; ?>



          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?> 
        </select> 

        <div style="display:none">
          <br> 
          <label for="exampleInputEmail1">Sponsor</label>  
          <em><lable>Students</lable></em><br>
          <select name="sponsor_students[]" multiple class="form-control">
          <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> 
            <option value="<?php echo e($student->id); ?>"><?php echo e($student->first_name . ' ' . $student->last_name . ', ' . $student->course . ', ' . $student->year_level); ?></option> 
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>   
          </select>
        </div>
  
        <div style="display:none">
        <br>
        <label for="exampleInputEmail1">Sponsor</label>  
        <em><lable>Colleges</lable></em><br>
        <select name="sponsor_collge[]" multiple class="form-control">
          <?php $__currentLoopData = $data['college']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $college): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <option value="<?php echo e($college); ?>"><?php echo e($college); ?></option>  
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </select>  
        <br>
        </div>

        <div style="display:none">
        <label for="exampleInputEmail1">Sponsor</label>  
        <em><lable>Year</lable></em><br>
        <select name="sponsor_year[]" multiple class="form-control">
             <?php $__currentLoopData = $data['year']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yearNum => $yearVal): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <option value="<?php echo e($yearNum); ?>"><?php echo e($yearVal); ?></option>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </select> 
        <br>
        </div>


    </div>


    <div class="form-group">
      <label for="exampleSelect2">Participants </label> 
      <em><lable>College</lable></em><br>
      <select name="participant_collge[]" multiple class="form-control" id="exampleSelect2">
          <?php $__currentLoopData = $data['college']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $college): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

           <?php if(in_array($college, App\Student::listIdToArray($eventDetails->participant_collge))): ?>
            <option value="<?php echo e($college); ?>" selected><?php echo e($college); ?></option>   
            <?php else: ?> 
                  <option value="<?php echo e($college); ?>"><?php echo e($college); ?></option>   
            <?php endif; ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </select>
    </div> 

    <div class="form-group"  style="display:none" >

      <label for="exampleSelect2">Participants</label> 
      <em><lable>Religion</lable></em><br>
      <select name="participant_religion[]" multiple class="form-control" id="exampleSelect2">
          <?php $__currentLoopData = $data['religion']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <option value="<?php echo e($religion); ?>"><?php echo e($religion); ?></option>  
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </select>
    </div> 

    <div class="form-group">
      <label for="exampleSelect2">Participants</label> 
      <em><lable>College Year</lable></em><br>
      <select name="participant_year[]" multiple class="form-control" id="exampleSelect2">
          <?php $__currentLoopData = $data['year']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yearNum => $yearVal): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

          
           <?php if(in_array($yearNum, App\Student::listIdToArray($eventDetails->participant_year))): ?>   
           <option value="<?php echo e($yearNum); ?>" selected><?php echo e($yearVal); ?></option>   
            <?php else: ?> 
                     <option value="<?php echo e($yearNum); ?>"><?php echo e($yearVal); ?></option>  
            <?php endif; ?> 
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </select>
    </div> 

    <div class="form-group">
      <label for="exampleSelect2">Date Time Started</label>
       at <b> <?php echo e($eventDetails->date_time_start); ?> </b><br>
      <input name="date_time_start" type="datetime-local"  class="form-control" value="<?php echo e($eventDetails->date_time_start); ?>" >
    </div>  

    <div class="form-group">
    
      <label for="exampleSelect2">Date Time End</label>  
       at <b> <?php echo e($eventDetails->date_time_end); ?> </b><br>
      <input name="date_time_end" type="datetime-local"  class="form-control" value="" >
    </div> 







  <button type="submit" class="btn btn-primary">Update</button>
</form>