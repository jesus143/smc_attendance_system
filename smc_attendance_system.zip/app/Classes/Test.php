<?php 
namespace App\Classes; 

class Test {
	function __construct()
	{
		print "Test";
	}
}